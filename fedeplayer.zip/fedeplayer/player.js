// FedePlayer - content script (StreamWish, EarnVids, UQLOAD, DOOD, NETU, Streamtape)
(function () {
  "use strict";
  var _h = location.host;
  var CANAL = _h.indexOf("filelions") >= 0 ? "earnvids"
            : _h.indexOf("streamtape") >= 0 ? "streamtape"
            : _h.indexOf("uqload") >= 0 ? "uqload"
            : (_h.indexOf("dood") >= 0 || _h.indexOf("playmogo") >= 0 || _h.indexOf("d000d") >= 0 || _h.indexOf("ds2play") >= 0 || _h.indexOf("mogo") >= 0 || _h.indexOf("vidply") >= 0) ? "dood"
            : (_h.indexOf("netu") >= 0 || _h.indexOf("waaw") >= 0 || _h.indexOf("hqq") >= 0) ? "netu"
            : "streamwish";
  var SOFT = (CANAL === "streamtape" || CANAL === "netu" || CANAL === "dood");
  var FP_VERSION = "1.3.0";
  var T0 = performance.now();
  function log() { try { console.log.apply(console, ["[FedePlayer/" + CANAL + "]"].concat([].slice.call(arguments))); } catch (e) {} }
  log("iniciado v" + FP_VERSION);

  // 1) POPUPS
  try { Object.defineProperty(window, "open", { configurable: false, get: function () { return function () { return null; }; }, set: function () {} }); }
  catch (e) { try { window.open = function () { return null; }; } catch (e2) {} }
  try {
    var _click = HTMLElement.prototype.click;
    HTMLElement.prototype.click = function () {
      if (this.tagName === "A" && this.target === "_blank" && !(this.closest && this.closest(".jwplayer, .jw-wrapper"))) return;
      return _click.apply(this, arguments);
    };
  } catch (e) {}
  function anclaDeAd(t) { if (!t || !t.closest) return null; var a = t.closest("a"); if (!a) return null; if (a.closest(".jwplayer, .jw-wrapper")) return null; return a; }
  ["pointerdown", "mousedown", "mouseup", "click", "auxclick"].forEach(function (tipo) {
    window.addEventListener(tipo, function (e) { var a = anclaDeAd(e.target); if (a) { e.preventDefault(); e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); } }, true);
  });
  new MutationObserver(function (muts) { muts.forEach(function (m) { m.addedNodes && m.addedNodes.forEach(function (n) { if (n.nodeType === 1 && n.querySelectorAll) n.querySelectorAll('a[target="_blank"]').forEach(function (a) { if (!a.closest(".jwplayer, .jw-wrapper")) a.removeAttribute("target"); }); }); }); }).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("beforeunload", function () {});

  // 2) CSS
  var css = '#adbd,.overdiv,.over,.video-ads,#overlay-ads,.advertisement,.vast,.vpaid,ins,[id^="ad_"]{display:none!important}'
    + '.jw-controls,.jw-controlbar,.jw-display,.jw-display-icon-container,.jw-title,.jw-logo,.jw-overlays,.jw-nextup-container,.jw-rightclick,.jw-preview,.jw-captions,.jw-float-icon{display:none!important;opacity:0!important;pointer-events:none!important}'
    + 'video{width:100%!important;height:100%!important;object-fit:contain!important;background:#000!important}'
    + 'html,body{background:#000!important;margin:0!important;overflow:hidden!important}';
  if (!SOFT) css += 'iframe{display:none!important}body>div[style*="position: fixed"],body>div[style*="z-index"]{display:none!important}.jwplayer,.jw-wrapper,.jw-media{background:#000!important}';
  (function () { var s = document.createElement("style"); s.textContent = css; (document.head || document.documentElement).appendChild(s); })();

  function matarOverlays() {
    if (SOFT) return;
    document.querySelectorAll("div,ins,a,aside,section").forEach(function (e) {
      if (e.closest(".jwplayer, .jw-wrapper")) return;
      if (e.querySelector && e.querySelector("video, .jwplayer")) return;
      var z = parseInt(getComputedStyle(e).zIndex, 10);
      if (z >= 9999) e.style.setProperty("display", "none", "important");
    });
  }
  var matados = 0; var iv = setInterval(function () { matarOverlays(); if (++matados > 40) clearInterval(iv); }, 800);
  document.addEventListener("DOMContentLoaded", matarOverlays);

  // 3) AVISAR / RECIBIR
  function avisarPadre(tipo, extra) { try { parent.postMessage(Object.assign({ canal: CANAL, tipo: tipo }, extra || {}), "*"); } catch (e) {} }
  function jw() { try { return window.jwplayer ? window.jwplayer() : null; } catch (e) { return null; } }
  window.addEventListener("message", function (ev) {
    var d = ev.data || {}; if (d.canal !== "canal-cmd") return;
    var v = document.querySelector("video"); var p = jw();
    try {
      switch (d.cmd) {
        case "toggle": if (p && p.getState) { (p.getState() === "playing") ? p.pause() : p.play(); } else if (v) { v.paused ? v.play() : v.pause(); } break;
        case "play": p ? p.play() : v && v.play(); break;
        case "pause": p ? p.pause() : v && v.pause(); break;
        case "seek": if (p && p.seek) p.seek(d.value); else if (v) v.currentTime = d.value; break;
        case "volume": if (v) { v.muted = d.value === 0; v.volume = d.value; } if (p) { p.setMute(d.value === 0); p.setVolume(Math.round(d.value * 100)); } break;
        case "mute": if (v) v.muted = !v.muted; if (p) p.setMute(v ? v.muted : true); break;
      }
    } catch (e) {}
  });

  // 4) VOLUMEN GRADUAL
  function fadeIn(v, ms) {
    if (v.__fading) return; v.__fading = true; v.muted = false;
    try { if (window.jwplayer) jwplayer().setMute(false); } catch (e) {}
    var pasos = 20, dt = (ms || 2500) / pasos, i = 0;
    var id = setInterval(function () {
      i++;
      if (v.paused) { clearInterval(id); v.__fading = false; v.muted = true; try { if (window.jwplayer) jwplayer().setMute(true); } catch (e) {} v.play().catch(function () {}); return; }
      v.volume = Math.min(1, i / pasos);
      try { if (window.jwplayer) jwplayer().setVolume(Math.round(v.volume * 100)); } catch (e) {}
      if (i >= pasos) clearInterval(id);
    }, dt);
  }

  // 5) AUTOPLAY + ESTADO
  function engancharVideo(v) {
    if (!v || v.__e) return; v.__e = true;
    v.muted = true; v.setAttribute("muted", "");
    var tryplay = function () { v.play().catch(function () {}); };
    tryplay(); v.addEventListener("canplay", tryplay, { once: true }); v.addEventListener("loadeddata", tryplay, { once: true });
    function snap(playing) {
      var t = v.currentTime, dur = v.duration || 0;
      try { if (window.jwplayer) { var p = jwplayer(); var jd = p.getDuration && p.getDuration(); var jt = p.getPosition && p.getPosition(); if (jd && jd > 0) dur = jd; if (typeof jt === "number" && jt >= 0) t = jt; } } catch (e) {}
      return { playing: playing != null ? playing : !v.paused, t: t, dur: dur, volume: v.volume, muted: v.muted };
    }
    v.addEventListener("play", function () { avisarPadre("play"); });
    v.addEventListener("ended", function () { avisarPadre("ended"); });
    v.addEventListener("timeupdate", function () { var s = snap(); avisarPadre("estado", s); if (s.dur && s.t >= s.dur - 0.8) avisarPadre("casi-fin"); });
    v.addEventListener("pause", function () { avisarPadre("estado", snap(false)); });
    v.addEventListener("error", function () { avisarPadre("error", { motivo: "video error" }); });
    setTimeout(function () { if (!v.paused && v.muted) fadeIn(v, 2000); }, 1200);
    var alGesto = function () { if (v.muted) fadeIn(v, 1200); };
    document.addEventListener("click", alGesto, { once: true }); document.addEventListener("keydown", alGesto, { once: true });
  }
  function engancharJW() {
    try {
      if (window.jwplayer && jwplayer().on && !window.__jw) {
        window.__jw = true;
        jwplayer().on("complete", function () { avisarPadre("ended"); });
        jwplayer().on("time", function (e) { var v = document.querySelector("video"); avisarPadre("estado", { playing: true, t: e.position, dur: e.duration || 0, volume: v ? v.volume : 1, muted: v ? v.muted : true }); if (e.duration && e.position >= e.duration - 0.8) avisarPadre("casi-fin"); });
        jwplayer().on("error", function (e) { avisarPadre("error", { motivo: (e && e.message) || "jw error" }); });
        jwplayer().on("setupError", function (e) { avisarPadre("error", { motivo: (e && e.message) || "jw setupError" }); });
        jwplayer().on("ready", function () { try { jwplayer().setMute(true); } catch (e) {} try { jwplayer().play(); } catch (e) {} });
        var chk = 0; var ei = setInterval(function () { try { if (window.jwplayer && jwplayer().getState && jwplayer().getState() === "error") { clearInterval(ei); avisarPadre("error", { motivo: "jw error state" }); } } catch (e) {} if (++chk > 25) clearInterval(ei); }, 600);
        return true;
      }
    } catch (e) {}
    return false;
  }
  new MutationObserver(function () { var v = document.querySelector("video"); if (v) engancharVideo(v); engancharJW(); matarOverlays(); }).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("load", function () { var v = document.querySelector("video"); if (v) engancharVideo(v); engancharJW(); avisarPadre("listo", { version: FP_VERSION }); });
  avisarPadre("fp", { version: FP_VERSION });

  // 6) STREAMTAPE/NETU/DOOD: empujon de play
  if (SOFT) {
    var kicks = 0;
    var kick = setInterval(function () {
      var v = document.querySelector("video");
      if (v) { v.muted = true; v.setAttribute("muted", ""); v.play().catch(function () {}); engancharVideo(v); }
      var sels = ["#videolink", "#play-button", ".play-overlay", ".play", ".vjs-big-play-button", ".plyr__control--overlaid"];
      sels.forEach(function (sel) { document.querySelectorAll(sel).forEach(function (b) { try { if (!b.closest('a[target="_blank"]')) b.click(); } catch (e) {} }); });
      if (++kicks > 12 || (v && !v.paused && v.currentTime > 0)) clearInterval(kick);
    }, 700);
  }
})();
