// FedePlayer - content script
// Hace lo mismo que los userscripts (StreamWish + EarnVids) pero como extensión:
//  - bloquea popups, oculta ads y controles del host
//  - autoplay muteado con fade-in
//  - recibe comandos de la página padre (play/pausa/seek/volumen)
//  - avisa estado y fin al padre (para barra de progreso y auto-siguiente)
// Gracias a "all_frames" del manifest, corre dentro del iframe sin configurar nada.

(function () {
  "use strict";

  // Canal segun el host (la página padre acepta todos).
  const CANAL = location.host.indexOf("filelions") >= 0 ? "earnvids"
              : location.host.indexOf("streamtape") >= 0 ? "streamtape"
              : location.host.indexOf("uqload") >= 0 ? "uqload"
              : "streamwish";
  // "soft": hosts cuyo reproductor NO es jwplayer; no aplicamos el bloqueo
  // agresivo (ocultar iframes / matar overlays) porque rompía el player.
  // UQLOAD sí es jwplayer, así que recibe el trato agresivo (limpia bien ads).
  const SOFT = (CANAL === "streamtape");

  const T0 = performance.now();
  const log = (...a) => console.log("[FedePlayer/" + CANAL + " +" + (performance.now() - T0).toFixed(0) + "ms]", ...a);
  log("iniciado");

  // ---------- 1) BLOQUEO DE POPUPS ----------
  try {
    Object.defineProperty(window, "open", {
      configurable: false,
      get() { return function () { log("BLOQUEADO window.open"); return null; }; },
      set() {},
    });
  } catch (e) { try { window.open = function () { return null; }; } catch (e2) {} }

  try {
    const _click = HTMLElement.prototype.click;
    HTMLElement.prototype.click = function () {
      if (this.tagName === "A" && this.target === "_blank" &&
          !(this.closest && this.closest(".jwplayer, .jw-wrapper"))) {
        log("BLOQUEADO a.click() popunder"); return;
      }
      return _click.apply(this, arguments);
    };
  } catch (e) {}

  function anclaDeAd(t) {
    if (!t || !t.closest) return null;
    const a = t.closest("a");
    if (!a) return null;
    if (a.closest(".jwplayer, .jw-wrapper")) return null;
    return a;
  }
  ["pointerdown", "mousedown", "mouseup", "click", "auxclick"].forEach((tipo) => {
    window.addEventListener(tipo, function (e) {
      const a = anclaDeAd(e.target);
      if (a) { e.preventDefault(); e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); }
    }, true);
  });

  function limpiarAnclas(root) {
    (root.querySelectorAll ? root.querySelectorAll('a[target="_blank"]') : []).forEach((a) => {
      if (!a.closest(".jwplayer, .jw-wrapper")) a.removeAttribute("target");
    });
  }
  new MutationObserver((muts) => {
    muts.forEach((m) => m.addedNodes && m.addedNodes.forEach((n) => { if (n.nodeType === 1) limpiarAnclas(n); }));
  }).observe(document.documentElement, { childList: true, subtree: true });

  window.addEventListener("beforeunload", function () {});

  // ---------- 2) DEJAR SOLO EL VIDEO ----------
  // CSS comun (no rompe ningun player): ocultar ads conocidos por clase/id.
  let css = `
    #adbd, .overdiv, .over, .video-ads, #overlay-ads, .advertisement,
    .vast, .vpaid, ins, [id^="ad_"], [class*="reklama"] { display: none !important; }
    .jw-controls, .jw-controlbar, .jw-display, .jw-display-icon-container,
    .jw-title, .jw-logo, .jw-overlays, .jw-nextup-container,
    .jw-rightclick, .jw-preview, .jw-captions, .jw-float-icon {
      display: none !important; opacity: 0 !important; pointer-events: none !important;
    }
    video { width: 100% !important; height: 100% !important; object-fit: contain !important; background:#000 !important; }
    html, body { background:#000 !important; margin:0 !important; overflow:hidden !important; }
  `;
  // CSS agresivo SOLO para jwplayer (StreamWish/EarnVids): ahi el player es un
  // <video> y todo iframe/overlay con z-index alto es publicidad. Streamtape NO
  // usa jwplayer y su contenedor sí puede ser un iframe / tener z-index alto,
  // asi que para Streamtape NO aplicamos esto (rompía el reproductor).
  if (!SOFT) {
    css += `
      iframe { display: none !important; }
      body > div[style*="position: fixed"], body > div[style*="z-index"] { display: none !important; }
      .jwplayer, .jw-wrapper, .jw-media { background: #000 !important; }
    `;
  }
  function inyectarCss() {
    const s = document.createElement("style");
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
  }
  inyectarCss();

  // Matador de overlays: los ads de estos hosts ponen <div> con z-index
  // altísimo (9999+, hasta 2147483647) ENCIMA del player. El reproductor real
  // (.jwplayer/.jw-wrapper/video) lo respetamos; el resto con z-index gigante
  // es publicidad -> lo ocultamos.
  function matarOverlays() {
    if (SOFT) return; // player no-jwplayer (Streamtape/Uqload): no tocar overlays
    document.querySelectorAll("div, ins, a, aside, section").forEach((e) => {
      if (e.closest(".jwplayer, .jw-wrapper")) return;
      if (e.querySelector && e.querySelector("video, .jwplayer")) return; // contenedor del player
      const z = parseInt(getComputedStyle(e).zIndex, 10);
      if (z >= 9999) e.style.setProperty("display", "none", "important");
    });
  }
  let matados = 0;
  const intervaloMatar = setInterval(() => { matarOverlays(); if (++matados > 40) clearInterval(intervaloMatar); }, 800);
  document.addEventListener("DOMContentLoaded", matarOverlays);

  // ---------- 3) AVISAR / RECIBIR ----------
  function avisarPadre(tipo, extra) {
    try { parent.postMessage(Object.assign({ canal: CANAL, tipo }, extra || {}), "*"); } catch (e) {}
  }
  function jw() { try { return window.jwplayer ? window.jwplayer() : null; } catch (e) { return null; } }

  window.addEventListener("message", (ev) => {
    const d = ev.data || {};
    if (d.canal !== "canal-cmd") return;
    const v = document.querySelector("video");
    const p = jw();
    try {
      switch (d.cmd) {
        case "toggle":
          if (p && p.getState) { (p.getState() === "playing") ? p.pause() : p.play(); }
          else if (v) { v.paused ? v.play() : v.pause(); }
          break;
        case "play":  p ? p.play() : v && v.play(); break;
        case "pause": p ? p.pause() : v && v.pause(); break;
        case "seek":  if (p && p.seek) p.seek(d.value); else if (v) v.currentTime = d.value; break;
        case "volume":
          if (v) { v.muted = d.value === 0; v.volume = d.value; }
          if (p) { p.setMute(d.value === 0); p.setVolume(Math.round(d.value * 100)); }
          break;
        case "mute":
          if (v) v.muted = !v.muted;
          if (p) p.setMute(v ? v.muted : true);
          break;
      }
    } catch (e) { log("cmd error", d.cmd, e); }
  });

  // ---------- 4) VOLUMEN GRADUAL ----------
  function fadeIn(v, ms) {
    if (v.__fading) return;
    v.__fading = true; v.muted = false;
    try { if (window.jwplayer) window.jwplayer().setMute(false); } catch (e) {}
    const pasos = 20, dt = (ms || 2500) / pasos; let i = 0;
    const id = setInterval(() => {
      i++;
      if (v.paused) { clearInterval(id); v.__fading = false; v.muted = true; try { if (window.jwplayer) window.jwplayer().setMute(true); } catch (e) {} v.play().catch(() => {}); return; }
      v.volume = Math.min(1, i / pasos);
      try { if (window.jwplayer) window.jwplayer().setVolume(Math.round(v.volume * 100)); } catch (e) {}
      if (i >= pasos) clearInterval(id);
    }, dt);
  }

  // ---------- 5) AUTOPLAY + ENGANCHES ----------
  function engancharVideo(v) {
    if (!v || v.__canalEnganchado) return;
    v.__canalEnganchado = true;
    v.muted = true; v.setAttribute("muted", "");
    const intentarPlay = () => v.play().catch(() => {});
    intentarPlay();
    v.addEventListener("canplay", intentarPlay, { once: true });
    v.addEventListener("loadeddata", intentarPlay, { once: true });
    // Estado: tomamos duración/posición de jwplayer si el <video> no las tiene
    // (UQLOAD, p.ej., deja video.duration en null y solo jwplayer las sabe).
    function snap(playing) {
      let t = v.currentTime, dur = v.duration || 0;
      try {
        if (window.jwplayer) {
          const p = jwplayer();
          const jd = p.getDuration && p.getDuration();
          const jt = p.getPosition && p.getPosition();
          if (jd && jd > 0) dur = jd;
          if (typeof jt === "number" && jt >= 0) t = jt;
        }
      } catch (e) {}
      return { playing: playing != null ? playing : !v.paused, t, dur, volume: v.volume, muted: v.muted };
    }
    v.addEventListener("play", () => avisarPadre("play"));
    v.addEventListener("ended", () => avisarPadre("ended"));
    v.addEventListener("timeupdate", () => {
      const s = snap();
      avisarPadre("estado", s);
      if (s.dur && s.t >= s.dur - 0.8) avisarPadre("casi-fin");
    });
    v.addEventListener("pause", () => avisarPadre("estado", snap(false)));
    v.addEventListener("error", () => avisarPadre("error", { motivo: "video error" }));

    // Desmuteo automático: UN SOLO intento (no reintentamos, para no llenar el
    // log con advertencias de Chrome). Si lo permite (sitio con engagement), el
    // volumen sube solo; si no, queda muteado hasta el primer gesto del usuario.
    setTimeout(() => { if (!v.paused && v.muted) fadeIn(v, 2000); }, 1200);
    const alGesto = () => { if (v.muted) fadeIn(v, 1200); };
    document.addEventListener("click", alGesto, { once: true });
    document.addEventListener("keydown", alGesto, { once: true });
  }
  function engancharJW() {
    try {
      if (window.jwplayer && window.jwplayer().on && !window.__jwEnganchado) {
        window.__jwEnganchado = true;
        window.jwplayer().on("complete", () => avisarPadre("ended"));
        window.jwplayer().on("time", (e) => {
          const v = document.querySelector("video");
          avisarPadre("estado", { playing: true, t: e.position, dur: e.duration || 0, volume: v ? v.volume : 1, muted: v ? v.muted : true });
          if (e.duration && e.position >= e.duration - 0.8) avisarPadre("casi-fin");
        });
        window.jwplayer().on("error", (e) => avisarPadre("error", { motivo: (e && e.message) || "jw error" }));
        window.jwplayer().on("setupError", (e) => avisarPadre("error", { motivo: (e && e.message) || "jw setupError" }));
        window.jwplayer().on("ready", () => { try { window.jwplayer().setMute(true); } catch (e) {} try { window.jwplayer().play(); } catch (e) {} });
        return true;
      }
    } catch (e) {}
    return false;
  }
  new MutationObserver(() => {
    const v = document.querySelector("video");
    if (v) engancharVideo(v);
    engancharJW();
    matarOverlays();
  }).observe(document.documentElement, { childList: true, subtree: true });

  window.addEventListener("load", () => {
    const v = document.querySelector("video");
    if (v) engancharVideo(v);
    engancharJW();
    avisarPadre("listo");
  });

  // STREAMTAPE/UQLOAD: pueden no autoreproducir y nuestra capa tapa su botón,
  // así que los arrancamos desde adentro: reintentamos play() y clickeamos el
  // botón de play interno.
  if (SOFT) {
    let kicks = 0;
    const kick = setInterval(() => {
      const v = document.querySelector("video");
      if (v) {
        v.muted = true; v.setAttribute("muted", "");
        v.play().catch(() => {});
        engancharVideo(v);
      }
      // botones de play típicos de Streamtape
      document.querySelectorAll(
        "#videolink, #play-button, .play-overlay, .play, #ideo_html5_api, [onclick*='play'], .vjs-big-play-button"
      ).forEach((b) => { try { if (!b.closest("a[target=_blank]")) b.click(); } catch (e) {} });
      if (++kicks > 12 || (v && !v.paused && v.currentTime > 0)) {
        clearInterval(kick);
        if (v && v.currentTime > 0) log("Streamtape arrancó");
      }
    }, 700);
  }
})();
